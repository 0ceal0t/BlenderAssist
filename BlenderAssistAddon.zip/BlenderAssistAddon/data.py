import bpy

class ExcludeBone(bpy.types.PropertyGroup):
	bone: bpy.props.StringProperty()